        <!-- Begin Page Content -->
        <div class="container">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Tambah Data Mahasiswa</h1>

          <div class="card">
                <div class="card-body">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama">  
                            <small class="form-text text-danger"><?= form_error('nama'); ?></small>
                        </div>

                        <div class="form-group">
                            <label for="nama">NIM</label>
                            <input type="text" class="form-control" name="nim" id="nim" placeholder="Hanya 8 Karakter">  
                            <small class="form-text text-danger"><?= form_error('nim'); ?></small>
                        </div>

                        <div class="form-group">
                            <label for="nama">Email</label>
                            <input type="text" class="form-control" name="email" id="email" placeholder="example@email.com">  
                            <small class="form-text text-danger"><?= form_error('email'); ?></small>
                        </div>

                        <div class="form-group">
                        <label for="jurusan">Jurusan</label>
                            <select class="form-control" id="jurusan" name="jurusan">
                                <option value="Teknik Informatika">Teknik Informatika</option>
                                <option value="Teknik Komputer">Teknik Komputer</option>
                                <option value="Teknik Arsitektur">Teknik Arsitektur</option>
                                <option value="Akuntansi">Akuntansi</option>
                                <option value="Ekonomi">Ekonomi</option>
                                <option value="Hubungan Internasional">Hubungan Internasional</option>
                            </select> 
                        </div>
                        <button type="submit" name="tambah" class="btn btn-primary btn-sm">Tambah Data</button>
                    </form>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->