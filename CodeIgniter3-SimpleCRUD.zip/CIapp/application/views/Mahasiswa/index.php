 <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <!-- <h1 class="h3 mb-2 text-gray-800">Tables</h1>
          <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p> -->
            <?php if ($this->session->flashdata() ) : ?>
                    <div class="row mt-3">
                        <div class="col-lg">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                Data <strong>Sukses</strong> <?= $this->session->flashdata('flash') ?>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    </div>  
              <?php endif; ?>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Daftar Mahasiswa</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-borderless" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Nama</th>
                      <th>Nomor Induk Mahasiswa</th>
                      <th>Email</th>
                      <th>Jurusan</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Nama</th>
                      <th>Nomor Induk Mahasiswa</th>
                      <th>Email</th>
                      <th>Jurusan</th>
                    </tr>
                  </tfoot>
                  <tbody>
                        <?php foreach ($mahasiswa as $mhs) :?>
                            <tr>
                                <td><?= $mhs['nama']?></td>
                                <td><?= $mhs['nim']?></td>
                                <td><?= $mhs['email']?></td>
                                <td><?= $mhs['jurusan']?></td>
                                <td class="text-center">
                                    <a href="<?= base_url(); ?>mahasiswa/update/<?= $mhs['id']; ?>"><i class="fas fa-pen-square mx-1" data-toggle="modal" data-target="#conditionModal"></i></a>
                                    <a href="<?= base_url(); ?>mahasiswa/hapus/<?= $mhs['id']; ?>" onclick="return confirm('Data akan dihapus?');"><i class="fas fa-times mx-1"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                  </tbody>
                </table>
                <div class="text">
                        <a class="btn btn-primary btn-sm" href="<?= base_url();?>mahasiswa/tambah">Tambah Data Mahasiswa</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->