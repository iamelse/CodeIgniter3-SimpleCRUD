        <!-- Begin Page Content -->
        <div class="container">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Blank Page</h1>
          <div class="card">
                <div class="card-body">
                    <form action="" method="post">
                    <input type="hidden" name="id" value="<?= $mahasiswa['id'] ?>">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama" value="<?= $mahasiswa['nama'] ?>">  
                            <small class="form-text text-danger"><?= form_error('nama'); ?></small>
                        </div>

                        <div class="form-group">
                            <label for="nama">NIM</label>
                            <input type="text" class="form-control" name="nim" id="nim" placeholder="Hanya 8 Karakter" value="<?= $mahasiswa['nim'] ?>">  
                            <small class="form-text text-danger"><?= form_error('nim'); ?></small>
                        </div>

                        <div class="form-group">
                            <label for="nama">Email</label>
                            <input type="text" class="form-control" name="email" id="email" placeholder="example@email.com" value="<?= $mahasiswa['email'] ?>">  
                            <small class="form-text text-danger"><?= form_error('email
                            '); ?></small>
                        </div>

                        <div class="form-group">
                        <label for="jurusan">Jurusan</label>
                            <select class="form-control" id="jurusan" name="jurusan">
                                <?php foreach($jurusan as $jur) : ?>
                                    <?php if ($jur == $mahasiswa['jurusan'] ) : ?> 
                                        <option value="<?= $jur;?>" selected><?= $jur;?></option>
                                    <?php else : ?>
                                        <option value="<?= $jur;?>"><?= $jur;?></option>
                                    <?php endif ?>
                                <?php endforeach; ?>
                            </select> 
                        </div>
                        <div class="text-center">
                            <button type="submit" name="update" class="btn btn-primary btn-sm">Perbarui Data</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->