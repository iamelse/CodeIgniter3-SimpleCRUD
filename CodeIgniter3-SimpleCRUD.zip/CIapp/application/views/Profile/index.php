 <!-- Begin Page Content -->
 <div class="container-fluid">

<!-- Page Heading -->
<!-- <h1 class="h3 mb-2 text-gray-800">Tables</h1>
<p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p> -->
<div class="card shadow mb-4">
  <div class="text-center card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Profile Admin</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-borderless" id="dataTable" width="100%" cellspacing="0">
        <tbody class="text-center">
          <tr>
            <div class="text-center">
                <img class="img-fluid mb-5 w-50 rounded-circle" src="https://scontent.fcgk7-1.fna.fbcdn.net/v/t1.0-9/p960x960/53150435_979077232291924_5535750409710206976_o.jpg?_nc_cat=100&_nc_sid=85a577&_nc_eui2=AeGIQS-8SckEidwPNno3tFzY5bXRVFBJiE3ltdFUUEmITclyfYhFpey8FYAcO8exiuGKgLG5ic4xe6g8jF1aprw5&_nc_oc=AQndiLQDJ4hQA3ebogjARUWiJjmsORuLk6dB69D8U8lgr_i2LVkT4Uu-4JX03erC7vw&_nc_ht=scontent.fcgk7-1.fna&_nc_tp=6&oh=5da0b036db2962dcbcc4f4f5e908e13e&oe=5EF20E25">
            </div>
          </tr>
          <tr>
            <td><?= $user['nama']; ?></td>
          </tr>
          <tr>
            <td><?= $user['email']; ?></td>
          </tr>
        </tbody>
      </table>
      <div class="text-center mb-4">
              <a class="btn btn-info btn-sm" href="<?= base_url();?>profile/editProfile/33">Ubah Profile</a>
      </div>
    </div>
  </div>
</div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->