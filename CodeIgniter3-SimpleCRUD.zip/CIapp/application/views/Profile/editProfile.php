        <!-- Begin Page Content -->
        <div class="container">

          <!-- Page Heading -->
          <div class="card mb-4">
                <div class="card-body">
                    <form action="" method="post">
                    <input type="hidden" name="id" value="<?= $user['id']; ?>">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama" value="<?= $user['nama']; ?>">  
                            <small class="form-text text-danger"><?= form_error('nama'); ?></small>
                        </div>

                        <div class="form-group">
                            <label for="nama">Email</label>
                            <input read-only type="text" class="form-control" name="email" id="email" placeholder="example@email.com" value="<?= $user['email']; ?>">  
                            <small class="form-text text-danger"><?= form_error('email'); ?></small>
                        </div>
                        <div class="text-center">
                            <button type="submit" name="update" class="btn btn-primary btn-sm">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->