<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_model extends CI_model {
    public function getDataById()
    {
        return $this->db->get('user')->result_array();
    }

    public function updateNama()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "email" => $this->input->post('email', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('user', $data);
    }
}