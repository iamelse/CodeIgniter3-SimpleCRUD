<?php

class Home extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mahasiswa_model');
        $this->load->library('form_validation');
      
  }

    public function index($nama = '')
    {
        $data['judul'] = 'Home';
        $data['mahasiswa'] = $this->Mahasiswa_model->getAllMahasiswa();
        $data['nama'] = $nama;
        $this->load->view('templates/header_index',$data);
        $this->load->view('home/index');
        $this->load->view('templates/footer_index');
    }
}