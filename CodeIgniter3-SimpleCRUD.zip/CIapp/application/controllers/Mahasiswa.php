<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Mahasiswa extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mahasiswa_model');
        $this->load->library('form_validation');
        
        if($this->session->userdata('is_login')==FALSE)
        {
        redirect('auth');
        }
      
  }

    public function index()
    {
        $data['judul'] = 'Daftar Mahasiswa';
        $data['mahasiswa'] = $this->Mahasiswa_model->getAllMahasiswa();
        $this->load->view('templates/header', $data);
        $this->load->view('Mahasiswa/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['judul'] = 'Form Tambah Data';
        $data['jurusan'] = ['Teknik Informatika','Teknik Komputer','Teknik Arsitektur','Akuntansi','Ekonomi','Hubungan Internasional'];

        $this->form_validation->set_rules('nama','Nama','required');
        $this->form_validation->set_rules('email','Email','required|valid_email');
        $this->form_validation->set_rules('nim','NIM','required|numeric');
        
        if ($this->form_validation->run()==FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('Mahasiswa/tambah');
            $this->load->view('templates/footer');
        } else {
            $this->Mahasiswa_model->tambahDataMahasiswa();
            $this->session->set_flashdata('flash','Ditambahkan');
            redirect('mahasiswa');
        }
    }

    public function update($id)
    {
        $data['judul'] = 'Form Update Data';
        $data['mahasiswa'] = $this->Mahasiswa_model->getMahasiswaById($id);
        $data['jurusan'] = ['Teknik Informatika','Teknik Komputer','Teknik Arsitektur','Akuntansi','Ekonomi','Hubungan Internasional'];

        $this->form_validation->set_rules('nama','Nama','required');
        $this->form_validation->set_rules('email','Email','required|valid_email');
        $this->form_validation->set_rules('nim','NIM','required|numeric');
        
        if ($this->form_validation->run()==FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('Mahasiswa/update', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Mahasiswa_model->updateDataMahasiswa();
            $this->session->set_flashdata('flash','Diperbarui');
            redirect('mahasiswa');
        }
    }

    public function hapus($id)
    {
        $this->Mahasiswa_model->hapusDataMahasiswa($id);
        $this->session->set_flashdata('flash','Dihapus');
        redirect('mahasiswa');
    }

}