<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

         public function __construct() {
   	     parent::__construct();
                $this->load->model('m_user');
                $this->load->model('Mahasiswa_model');
                $this->load->model('Profile_model');
                $this->load->library('form_validation');
                if($this->session->userdata('is_login')==FALSE)
                {
                redirect('auth');
                }
         }

    public function index()
    {
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $data['judul'] = 'Profile Admin';
        $this->load->view('templates/header_profile', $data);
        $this->load->view('profile/index', $data);
        $this->load->view('templates/footer_profile');
    }

    public function editProfile($id)
    {
        $data['judul'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('nama','Nama','required');
        
        if ($this->form_validation->run()==FALSE) {
            $this->load->view('templates/header_profile', $data);
            $this->load->view('Profile/editProfile', $data);
            $this->load->view('templates/footer_profile');
        } else {
            $name = $this->input->post('nama');
            $email = $this->input->post('email');

            $this->db->set('nama', $name);
            $this->db->where('email', $email);
            $this->db->update('user');
            $this->session->set_flashdata('flash','Diperbarui');
            redirect('profile');
        }
    }
}